# mx520_sample

Sample client code using iu456 driver for mx520 cameras

## Build

Run the ``generate_VS2015.bat`` file. This will create

- a Visual Studio 2015 solution (``.build/build/imx520_sample.sln``)
- an executable of the sample code (``.build/output/Release/imx520_sample.exe``)