classdef FilterLevel < uint16
   enumeration
      Off           (0)
      Legacy        (200)
      Full          (255)
      Custom        (256)
   end
end