function royaleVersion = getVersion()
royaleVersion = royale.royale_matlab('getVersion');
end