/* Copyright 2015 The MathWorks, Inc. */

#ifndef MATLAB_DATA_ENUMERATION_HPP
#define MATLAB_DATA_ENUMERATION_HPP

namespace matlab {
    namespace data {
        class Enumeration {};
    }
}

#endif
